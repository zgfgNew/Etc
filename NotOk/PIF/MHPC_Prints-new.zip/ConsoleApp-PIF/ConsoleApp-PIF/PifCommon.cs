﻿using Newtonsoft.Json;
using System.Diagnostics;


namespace PIF
{
    public class PifCommon
    {
        const string fPath = "C:\\Temp\\PIF\\";

        public static string ConvertToAPILevel(string? Android = null)
        {
            if (string.IsNullOrWhiteSpace(Android))
                return "23";

            if (string.Compare(Android, "2") > 0)
            {
                if (string.Compare(Android, "4.4W") < 0)
                    return "19";
                else if (string.Compare(Android, "5") < 0)
                    return "20";

                else if (string.Compare(Android, "5.1") < 0)
                    return "21";

                else if (string.Compare(Android, "6") < 0)
                    return "22";

                else if (string.Compare(Android, "7") < 0)
                    return "23";
                else if (string.Compare(Android, "7.1") < 0)
                    return "24";

                else if (string.Compare(Android, "8") < 0)
                    return "25";
                else if (string.Compare(Android, "8.1") < 0)
                    return "26";

                else if (string.Compare(Android, "9") < 0)
                    return "27";

                return "28";
            }

           if (string.Compare(Android, "11") < 0)
                return "29";

            else if (string.Compare(Android, "12") < 0)
                return "30";
            else if (string.Compare(Android, "12L") < 0)
                return "31";
            else if (string.Compare(Android, "13") < 0)
                return "32";
            else if (string.Compare(Android, "14") < 0)
                return "33";

            return "34";
        }

        public static bool PrintToConsole { get; set; }

        public static bool PrintString(object? obj = null)
        {
            if (!PrintToConsole)
                return false;

            string? str = null;
            if (obj is not null)
                str = obj.ToString();

            var print = !string.IsNullOrWhiteSpace(str);
            Console.WriteLine(str);

            return print;
        }

        public static string? EncodeToJson(object? obj)
        {
            try
            {
                var bFormat = true;
                string? str = bFormat ? "Null object" : null;
                if (obj is null)
                    return str;

                var format = bFormat ? Formatting.Indented : Formatting.None;
                str = JsonConvert.SerializeObject(obj, format, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore });

                if (!bFormat && str is not null)
                    str = str.Replace(" ", "");

                if (bFormat)
                {
                    if (str is null)
                        str = "Json error";
                    else if (string.IsNullOrWhiteSpace(str))
                        str = "Empty Json";
                }
                else if (str is not null)
                    str = str.Replace(" ", "");

                return str;
            }
            catch (Exception exc)
            {
                PrintString(exc.Message);
                return null;
            }
        }

        public static bool PrintToFile(object? obj, string name)
        {
            try
            {
                if (!string.IsNullOrEmpty(name))
                    name = "-" + name;

                var fName = fPath + "pif" + name + ".json";
                if (string.IsNullOrWhiteSpace(fName))
                    return false;

                string? str = null;
                if (obj is not null)
                    str = obj.ToString();

                StreamWriter file = new StreamWriter(fName);
                file.WriteLine(str);

                file.Close();
                return true;
            }
            catch (Exception exc)
            {
                PrintString(exc.Message);
                return false;
            }
        }

        public static bool RaedFromFile(string? fName)
        {
            try
            {
                fName = fPath + fName;
                if (string.IsNullOrWhiteSpace(fName) || !File.Exists(fName))
                    return false;

                var file = new StreamReader(fName);
                string? line = null;
                var ret = false;
                while ((line = file.ReadLine()) != null)
                    ret = ProcessLine(line) || ret;

                file.Close();
                Debug.Assert(ret);
                return ret;
            }
            catch (Exception exc)
            {
                PrintString(exc.Message);
                return false;
            }
        }

        public static bool ProcessLine(string? line)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(line))
                    return false;

                // prints.sh line example:
                // NAME (ANDROID):MANUFACTURER:MODEL=FINGERPRINT__PATCH;FINGERPRINT__PATCH
                // HTC U12 Plus (8.0.0 & 9):HTC:HTC U12+=htc/imeuhl_00617/htc_imeuhl:8.0.0/OPR1.170623.032/1041457.3:user/release-keys__2018-06-01;htc/imeuhl_00617/htc_imeuhl:9/PQ2A.190205.003/1087121.1:user/release-keys__2019-07-0
                line = line.Trim();
                var data = line.Split(new string[] { "=" }, StringSplitOptions.None);
                if (data.Length < 2)
                    return false;  

                var name = data[0];
                var fingerprints = data[1];
                if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(fingerprints))
                    return false;

                // NAME (ANDROID):MANUFACTURER:MODEL
                // HTC U12 Plus (8.0.0 & 9):HTC:HTC U12+
                data = name.Trim().Split(new string[] { ":" }, StringSplitOptions.None);
                if (data.Length < 3)
                    return false;

                name = data[0];
                var manufacturer = data[1];
                var model = data[2];
                if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(manufacturer) || string.IsNullOrWhiteSpace(model))
                    return false;

                // NAME (ANDROID)
                // HTC U12 Plus (8.0.0 & 9)
                data = name.Trim().Split(new string[] { "(" }, StringSplitOptions.None);
                if (data.Length < 2)
                    return false;

                name = data[0];
                var android = data[1].Trim(')');
                var api = PifCommon.ConvertToAPILevel(android);
                if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(api))
                    return false;

                // FINGERPRINT__PATCH;FINGERPRINT__PATCH
                // htc/imeuhl_00617/htc_imeuhl:8.0.0/OPR1.170623.032/1041457.3:user/release-keys__2018-06-01;htc/imeuhl_00617/htc_imeuhl:9/PQ2A.190205.003/1087121.1:user/release-keys__2019-07-0
                data = fingerprints.Split(new string[] { ";" }, StringSplitOptions.None);
                if (data.Length < 1)
                    return false;

                var ret = true;
                for (var count = 0; count < data.Length;)
                {
                    var fingerprint = data[count];
                    if (!string.IsNullOrWhiteSpace(fingerprint))
                        ret = ProcessFingerprint(name, manufacturer, model, api, fingerprint, count++, line) && ret;
                }
                return ret;
            }
            catch (Exception exc)
            {
                PifCommon.PrintString(exc.Message);
                return false;
            }
        }

        public static bool ProcessFingerprint(string? name, string? manufacturer, string? model, string? api, string? fingerprint, int count, string? comment = null)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(manufacturer) || string.IsNullOrWhiteSpace(model) || string.IsNullOrWhiteSpace(api) || string.IsNullOrWhiteSpace(fingerprint) || count < 0)
                    return false;

                name = name.Trim();
                if (count > 0)
                    name += "-" + count.ToString();

                // BRAND/PRODUCT/DEVICE:RELEASE/BUILD/INCREMENTAL:TYPE:TAGS__PATCH
                // google/husky/husky:14/UD1A.231105.004/11010374:user/release-keys__2023-11-05
                var data = fingerprint.Split(new string[] { "__" }, StringSplitOptions.None);
                if (data.Length < 1)
                    return false;

                fingerprint = data[0];
                if (string.IsNullOrWhiteSpace(fingerprint))
                    return false;

                string? patch = null;
                if (data.Length > 1)
                    patch = data[1];

                // BRAND/PRODUCT/DEVICE:RELEASE/BUILD/INCREMENTAL:TYPE:TAGS
                // google/husky/husky:14/UD1A.231105.004/11010374:user/release-keys
                data = fingerprint.Split(new string[] { "/" }, StringSplitOptions.None);
                if (data.Length < 6)
                    return false;

                var brand = data[0];
                var product = data[1];
                var device = data[2];
                var build = data[3];
                var incr = data[4];
                var tag = data[5];
                if (string.IsNullOrWhiteSpace(brand) || string.IsNullOrWhiteSpace(product) || string.IsNullOrWhiteSpace(device) || string.IsNullOrWhiteSpace(build) || string.IsNullOrWhiteSpace(incr) || string.IsNullOrWhiteSpace(tag))
                    return false;

                // DEVICE:RELEASE
                // husky:14
                data = device.Split(new string[] { ":" }, StringSplitOptions.None);
                if (data.Length < 2)
                    return false;

                device = data[0];
                var release = data[1];
                if (string.IsNullOrWhiteSpace(device) || string.IsNullOrWhiteSpace(release))
                    return false;

                // INCREMENTAL:TYPE
                // 11010374:user
                data = incr.Split(new string[] { ":" }, StringSplitOptions.None);
                if (data.Length < 2)
                    return false;

                incr = data[0];
                var typ = data[1];
                if (string.IsNullOrWhiteSpace(incr) || string.IsNullOrWhiteSpace(typ))
                    return false;

                var apiBuild = PifCommon.ConvertToAPILevel(release);
                if (string.Compare(apiBuild, api) < 0)
                    api = apiBuild;

                Pif pif = new Pif(name, comment, manufacturer, model, patch, api);
                var ret = pif.Set(fingerprint, brand, product, device, release, build, incr, typ, tag);
                if (!ret)
                    return false;

                ret = pif.PrintToJsonFile();
                Debug.Assert(ret);
                return ret;
            }
            catch (Exception exc)
            {
                PifCommon.PrintString(exc.Message);
                return false;
            }
        }
    }
}