﻿using System;
using System.Globalization;


namespace PIF
{
    public class Pif
    {
        const string RelKeys = "release-keys";

        protected static TextInfo ti = CultureInfo.CurrentCulture.TextInfo;

        public string? COMMENT;
        public string? MANUFACTURER;
        public string? MODEL;
        public string? PRODUCT;
        public string? DEVICE;
        public string? BRAND;
        public string? FINGERPRINT;
        public string? SECURITY_PATCH;
        public string? BUILD_ID;
        public string? RELEASE;
        public string? INCREMENTAL;
        public string? TYPE;
        public string? TAGS;
        public string? FIRST_API_LEVEL;

        protected string? Name;

        public Pif(string? name, string? comment, string? manufacturer, string? model, string? patch, string? api)
        {
            if (name != null)
                Name = name.Trim();

            if (manufacturer != null)
                MANUFACTURER = ti.ToTitleCase(manufacturer.Trim());

            if (model != null)
                MODEL = model.Trim();

            if (comment != null)
                COMMENT = comment.Trim();

            if (patch != null)
                SECURITY_PATCH = patch.Trim();

            FIRST_API_LEVEL = "25";
            if (api != null)
                FIRST_API_LEVEL = api.Trim();
        }

        public bool Set(string? fingerprint, string? brand, string? product, string? device, string? release, string? build, string? incr, string? typ, string? tag)
        {
            if (product != null)
                PRODUCT = product.Trim();

            if (device != null)
                DEVICE = device.Trim();

            if (brand != null)
                BRAND = brand.Trim();

            if (fingerprint != null)
                FINGERPRINT = fingerprint.Trim();

            if (build != null)
                BUILD_ID = build.Trim();

            if (release != null)
                RELEASE = release.Trim();

            if (incr != null)
                INCREMENTAL = incr.Trim();

            if (typ != null)
                TYPE = typ.Trim();

            if (tag != null)
                TAGS = tag.Trim();

            if (string.IsNullOrWhiteSpace(Name))
                Name = MANUFACTURER + "_" + MODEL;

            if (Name != null)
            {
                Name = Name.Trim();
                Name = Name.Replace(' ', '_');
                Name = Name.Replace('/', '_');
            }

            var ret = IsOk();
            return ret;
        }

        public bool IsOk()
        {
            var ret = !string.IsNullOrWhiteSpace(FIRST_API_LEVEL);
            if (!string.IsNullOrWhiteSpace(FIRST_API_LEVEL))
            {
                var api = false;
                api = (string.Compare(FIRST_API_LEVEL, "19") >= 0 && string.Compare(FIRST_API_LEVEL, "21") < 0) || api;  // A4.4
                api = (string.Compare(FIRST_API_LEVEL, "21") >= 0 && string.Compare(FIRST_API_LEVEL, "23") < 0) || api;  // A5
                api = (string.Compare(FIRST_API_LEVEL, "23") >= 0 && string.Compare(FIRST_API_LEVEL, "24") < 0) || api;  // A6
                api = (string.Compare(FIRST_API_LEVEL, "24") >= 0 && string.Compare(FIRST_API_LEVEL, "26") < 0) || api;  // A7
                api = (string.Compare(FIRST_API_LEVEL, "26") >= 0 && string.Compare(FIRST_API_LEVEL, "28") < 0) || api;  // A8
                api = (string.Compare(FIRST_API_LEVEL, "28") >= 0 && string.Compare(FIRST_API_LEVEL, "29") < 0) || api;  // A9
                api = (string.Compare(FIRST_API_LEVEL, "29") >= 0 && string.Compare(FIRST_API_LEVEL, "30") < 0) || api;  // A10
                api = (string.Compare(FIRST_API_LEVEL, "30") >= 0 && string.Compare(FIRST_API_LEVEL, "31") < 0) || api;  // A11
                api = (string.Compare(FIRST_API_LEVEL, "31") >= 0 && string.Compare(FIRST_API_LEVEL, "33") < 0) || api;  // A12
                ret = ret && api;
            }

            ret = ret && !string.IsNullOrWhiteSpace(PRODUCT);
            ret = ret && !string.IsNullOrWhiteSpace(DEVICE);
            ret = ret && !string.IsNullOrWhiteSpace(MANUFACTURER);
            ret = ret && !string.IsNullOrWhiteSpace(BRAND);
            ret = ret && !string.IsNullOrWhiteSpace(MODEL);

            ret = ret && !string.IsNullOrWhiteSpace(FINGERPRINT) && FINGERPRINT.EndsWith(RelKeys, StringComparison.InvariantCulture);
            ret = ret && (string.IsNullOrWhiteSpace(TAGS) || TAGS.Equals(RelKeys, StringComparison.InvariantCulture));

            ret = ret && !string.IsNullOrWhiteSpace(Name);
            return ret;
        }

        // Helpers

        public bool PrintToJsonFile()
        {
            var json = PifCommon.EncodeToJson(this);
            var ret = PifCommon.PrintToFile(json, Name);
            return ret;
        }
    }
}