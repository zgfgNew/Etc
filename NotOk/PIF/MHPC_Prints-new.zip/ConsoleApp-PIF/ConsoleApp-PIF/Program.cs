﻿using PIF;
using System.Diagnostics;


namespace PIF.Main
{
    public class Program
    {
        static void Main(string[] args)
        {
            ReadStrings();
            return;
        }

        static async Task ReadStrings()
        {
            PifCommon.PrintToConsole = true;

            if (false)  // Test
            {
                var line = "HTC U12 Plus (8.0.0 & 9):HTC:HTC U12+=htc/imeuhl_00617/htc_imeuhl:8.0.0/OPR1.170623.032/1041457.3:user/release-keys__2018-06-01;htc/imeuhl_00617/htc_imeuhl:9/PQ2A.190205.003/1087121.1:user/release-keys__2019-07-01";
                var ret = PifCommon.ProcessLine(line);
                Debug.Assert(ret);

                line = "Google Pixel 8 Pro (12):Google:Pixel 8 Pro=google/husky/husky:14/UD1A.231105.004/11010374:user/release-keys__2023-11-05";
                ret = PifCommon.ProcessLine(line);
                Debug.Assert(ret);
                return;
            }

            PifCommon.RaedFromFile("prints.txt");
        }
    }
}
