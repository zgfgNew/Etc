cd "${0%/*}"
echo "" >> _list.txt
pwd >> _list.txt
ls *.json* >> _list.txt
