cd "${0%/*}"
ls *.json* > _list.txt